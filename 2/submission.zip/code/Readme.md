# Way to Run the Code

Run the code in "main.ipynb". The results will be created in the "results" folder.