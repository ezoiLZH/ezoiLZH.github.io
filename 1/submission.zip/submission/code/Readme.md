# Way to Run the Code

Create a folder call "data" at the current directory and put the original images in the "data" folder. Run "main.py" and the results will be created in the "results" folder.